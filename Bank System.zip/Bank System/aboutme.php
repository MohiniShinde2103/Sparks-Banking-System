<?php include 'nav.php' ?>
<head>
<style>
.mypic
{
padding:20px;
}
.name
{
padding:20px;
}
.detail
{
align-content: center;
padding:20px;
padding-left: 350px;
padding-right: 350px;
}
</style>
</head>
<body>
<center>
<div class="mypic">
<img src="images/profile-img.jpg" width="200" height="200">
</div>
<div class="name">
<h2>Mohini Shinde</h2>
</div>
<div class="detail">
<p>Motivated and hard-working CSE undergraduate student with experience of working on web application development and software development. Interested in research oriented work. Currently trying to explore Data Science and Machine Learning fields. Projects in C, C++, Java, Python, HTML, CSS, JavaScript, JSP, VB .Net, Networking, Security, Data Science and Machine Learning. Dedicated towards achieving goals.</p>
<ul>
<li>Degree- BE in Computer Engineering</li>
<li>Institute- Pimpri Chinchwad College of Engineering, Pune</li>
<li>Portfolio- <a href="https://github.com/MohiniShinde2103">github</a>
LinkedIn- <a href="https://www.linkedin.com/in/mohini-shinde-428b55200">linkedin</a></li>
</ul>
</div>
</center>
</body>
<?php include 'footer.php' ?>