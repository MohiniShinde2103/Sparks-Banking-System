<body>
<footer class="footersection bg-dark" id="footerdiv">
      
    <div class="rights">
        <br/>All rights reserved<br><i class="fa fa-copyright" aria-hidden="true"> <strong>Mohini Shinde</strong> for the internship task at The Sparks Foundation.</i>
    </div>
</footer>
</body>